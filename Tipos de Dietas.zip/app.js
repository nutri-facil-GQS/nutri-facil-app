const express = require('express');
const app = express();
require('dotenv').config();

app.use(express.json());

app.use('/planos', require('./routes/planoRoutes'));
app.use('/alimentos', require('./routes/alimentoRoutes'));
app.use('/receitas', require('./routes/receitaRoutes'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
