const db = require('../db');

const buscarAlimentos = async (req, res) => {
  const { nome, grupo, dieta, calorias_min, calorias_max } = req.query;
  let query = `SELECT * FROM alimentos WHERE 1=1`;
  const params = [];

  if (nome) {
    params.push(`%${nome}%`);
    query += ` AND nome ILIKE $${params.length}`;
  }
  if (grupo) {
    params.push(grupo);
    query += ` AND grupo_alimentar = $${params.length}`;
  }
  if (calorias_min) {
    params.push(calorias_min);
    query += ` AND calorias >= $${params.length}`;
  }
  if (calorias_max) {
    params.push(calorias_max);
    query += ` AND calorias <= $${params.length}`;
  }

  try {
    const resultado = await db.query(query, params);
    res.json(resultado.rows);
  } catch (err) {
    res.status(500).json({ erro: 'Erro na busca de alimentos' });
  }
};

module.exports = { buscarAlimentos };

