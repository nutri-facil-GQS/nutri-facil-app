const Plano = require('../models/Plano');

const criarPlano = async (req, res) => {
  try {
    const novoPlano = await Plano.criarPlano(req.body);
    res.status(201).json(novoPlano);
  } catch (err) {
    res.status(500).json({ erro: 'Erro ao criar plano alimentar.' });
  }
};

module.exports = { criarPlano };

