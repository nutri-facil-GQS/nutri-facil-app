const Receita = require('../models/Receita');

const criarReceita = async (req, res) => {
  try {
    const id = await Receita.criarReceita(req.body);
    res.status(201).json({ mensagem: 'Receita criada com sucesso', id });
  } catch (err) {
    res.status(500).json({ erro: 'Erro ao criar receita' });
  }
};

module.exports = { criarReceita };

