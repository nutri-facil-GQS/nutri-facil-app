const db = require('../db');

const criarPlano = async (plano) => {
  const { usuario_id, objetivo, calorias_alvo, dieta_id } = plano;
  const result = await db.query(
    `INSERT INTO planos_alimentares (usuario_id, objetivo, calorias_alvo, dieta_id)
     VALUES ($1, $2, $3, $4) RETURNING *`,
    [usuario_id, objetivo, calorias_alvo, dieta_id]
  );
  return result.rows[0];
};

module.exports = { criarPlano };

