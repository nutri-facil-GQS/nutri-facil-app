const db = require('../db');

const criarReceita = async ({ nome, modo_preparo, tempo_preparo, rendimento, dieta_id, alimentos }) => {
  const result = await db.query(
    `INSERT INTO receitas (nome, modo_preparo, tempo_preparo, rendimento, dieta_id)
     VALUES ($1, $2, $3, $4, $5) RETURNING id`,
    [nome, modo_preparo, tempo_preparo, rendimento, dieta_id]
  );
  const receitaId = result.rows[0].id;

  for (const item of alimentos) {
    await db.query(
      `INSERT INTO ingredientes_receita (receita_id, alimento_id, quantidade, unidade)
       VALUES ($1, $2, $3, $4)`,
      [receitaId, item.alimento_id, item.quantidade, item.unidade]
    );
  }

  return receitaId;
};

module.exports = { criarReceita };

