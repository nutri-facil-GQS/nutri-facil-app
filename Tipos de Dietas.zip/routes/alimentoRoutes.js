const express = require('express');
const router = express.Router();
const alimentoController = require('../controllers/alimentoController');

router.get('/buscar', alimentoController.buscarAlimentos);

module.exports = router;

