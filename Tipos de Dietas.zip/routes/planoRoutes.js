const express = require('express');
const router = express.Router();
const planoController = require('../controllers/planoController');

router.post('/criar', planoController.criarPlano);

module.exports = router;

